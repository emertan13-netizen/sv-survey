import streamlit as st
import pandas as pd
import csv
import os
from datetime import datetime

# ── PAGE CONFIG ────────────────────────────────────────────
st.set_page_config(
    page_title="SupervisAI — User Research Survey",
    page_icon="🧠",
    layout="centered",
    initial_sidebar_state="collapsed"
)

# ── CUSTOM CSS ─────────────────────────────────────────────
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

    html, body, [class*="css"] { font-family: 'Inter', sans-serif; }

    .main { background-color: #f8fafc; }

    .title-block {
        background: linear-gradient(135deg, #0A1628 0%, #0D2847 100%);
        padding: 2rem 2rem 1.5rem 2rem;
        border-radius: 12px;
        margin-bottom: 1.5rem;
    }
    .title-block h1 {
        color: #2DBFB8;
        font-size: 2.2rem;
        font-weight: 700;
        margin: 0 0 0.25rem 0;
    }
    .title-block p {
        color: #7BAFD4;
        font-size: 0.95rem;
        margin: 0;
    }
    .title-block .meta {
        color: #3A6080;
        font-size: 0.82rem;
        margin-top: 0.5rem;
    }

    .hypothesis-box {
        background: #E8F4F7;
        border-left: 5px solid #028090;
        border-radius: 6px;
        padding: 1rem 1.25rem;
        margin: 1rem 0;
    }
    .hypothesis-box h4 { color: #028090; margin: 0 0 0.5rem 0; font-size: 0.9rem; }
    .hypothesis-box p { color: #333; margin: 0.2rem 0; font-size: 0.875rem; }

    .section-header {
        padding: 0.6rem 1rem;
        border-radius: 6px;
        margin: 1.5rem 0 0.75rem 0;
        font-weight: 600;
        font-size: 0.95rem;
    }
    .section-all { background: #E8F4F7; color: #028090; border-left: 5px solid #028090; }
    .section-sup { background: #FFF8E8; color: #C47A00; border-left: 5px solid #C47A00; }
    .section-tra { background: #EDFAF3; color: #1A7A4A; border-left: 5px solid #1A7A4A; }

    .purpose-note {
        background: #f8f8f8;
        border-left: 3px solid #ccc;
        padding: 0.4rem 0.75rem;
        font-size: 0.78rem;
        color: #888;
        font-style: italic;
        margin: 0.25rem 0 0.75rem 0;
        border-radius: 3px;
    }

    .badge {
        display: inline-block;
        padding: 0.2rem 0.6rem;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
        margin-bottom: 0.5rem;
    }
    .badge-all { background: #E8F4F7; color: #028090; }
    .badge-sup { background: #FFF8E8; color: #C47A00; }
    .badge-tra { background: #EDFAF3; color: #1A7A4A; }

    .success-box {
        background: linear-gradient(135deg, #E8F4F7, #EDFAF3);
        border: 2px solid #2DBFB8;
        border-radius: 12px;
        padding: 2rem;
        text-align: center;
        margin: 2rem 0;
    }
    .success-box h2 { color: #028090; }
    .success-box p { color: #555; }

    .stButton > button {
        background: linear-gradient(135deg, #028090, #2DBFB8);
        color: white;
        border: none;
        border-radius: 8px;
        padding: 0.6rem 2rem;
        font-weight: 600;
        font-size: 1rem;
        width: 100%;
        margin-top: 1rem;
    }
    .stButton > button:hover { background: linear-gradient(135deg, #025F6B, #028090); }

    .footer-note {
        background: #f0f0f0;
        border-top: 2px solid #028090;
        padding: 0.75rem 1rem;
        font-size: 0.78rem;
        color: #777;
        border-radius: 0 0 8px 8px;
        margin-top: 2rem;
        font-style: italic;
    }

    div[data-testid="stRadio"] label { font-size: 0.9rem; }
    div[data-testid="stCheckbox"] label { font-size: 0.9rem; }
</style>
""", unsafe_allow_html=True)

# ── RESPONSES FILE ─────────────────────────────────────────
RESPONSES_FILE = "responses.csv"

def save_response(data: dict):
    data["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    file_exists = os.path.isfile(RESPONSES_FILE)
    with open(RESPONSES_FILE, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=data.keys())
        if not file_exists:
            writer.writeheader()
        writer.writerow(data)

# ── SESSION STATE ──────────────────────────────────────────
if "submitted" not in st.session_state:
    st.session_state.submitted = False
if "responses" not in st.session_state:
    st.session_state.responses = {}

# ── SUBMITTED STATE ────────────────────────────────────────
if st.session_state.submitted:
    st.markdown("""
    <div class="success-box">
        <h2>🎉 Thank you for your response!</h2>
        <p>Your input will directly shape the development of SupervisAI.<br>
        We really appreciate you taking the time.</p>
    </div>
    """, unsafe_allow_html=True)
    st.stop()

# ── TITLE ──────────────────────────────────────────────────
st.markdown("""
<div class="title-block">
    <h1>🧠 SupervisAI</h1>
    <p>User Research Survey — AI-Powered Clinical Supervision Support for DClinPsy Trainees</p>
    <p class="meta">Anonymous · 5–7 minutes · Winter 2026</p>
</div>
""", unsafe_allow_html=True)

# ── INTRO ──────────────────────────────────────────────────
st.markdown("""
Thank you for taking part. Your responses are **anonymous** and will be used solely to inform 
an independent research project on AI-supported clinical supervision. There are no right or 
wrong answers — please respond based on your genuine experience.
""")

st.markdown("""
<div class="hypothesis-box">
    <h4>📌 This survey is designed to test three hypotheses:</h4>
    <p>1. Supervisor time on direct clinical session support is a primary barrier to services taking on more DClinPsy trainees</p>
    <p>2. Trainees currently lack adequate structured reflection between supervision sessions</p>
    <p>3. Clinicians would be open to adopting an AI tool that addressed these gaps, provided their key concerns were met</p>
</div>
""", unsafe_allow_html=True)

st.divider()

# ══════════════════════════════════════════════════════════
# SECTION 1 — ALL
# ══════════════════════════════════════════════════════════
st.markdown('<div class="section-header section-all">Section 1: About You</div>', unsafe_allow_html=True)
st.markdown('<span class="badge badge-all">🔵 ALL RESPONDENTS</span>', unsafe_allow_html=True)

# Q1
st.markdown("**Q1. What is your current role?**")
st.markdown('<div class="purpose-note">📌 Purpose: Determines branching path and allows findings to be split by role</div>', unsafe_allow_html=True)
q1 = st.radio("", [
    "DClinPsy supervisor",
    "DClinPsy trainee",
    "Both",
    "Other"
], key="q1", label_visibility="collapsed")

# Q2
st.markdown("**Q2. Have you ever used a digital tool to support clinical training or supervision?**")
st.markdown('<div class="purpose-note">📌 Purpose: Establishes baseline digital familiarity — essential in healthtech user research</div>', unsafe_allow_html=True)
q2 = st.radio("", [
    "Yes, regularly",
    "Yes, occasionally",
    "No, but open to it",
    "No, not interested"
], key="q2", label_visibility="collapsed")

st.divider()

# ══════════════════════════════════════════════════════════
# BRANCHING — SUPERVISOR PATH
# ══════════════════════════════════════════════════════════
if q1 in ["DClinPsy supervisor", "Both"]:
    st.markdown('<div class="section-header section-sup">Section 2: Supervision Experience — SUPERVISORS ONLY</div>', unsafe_allow_html=True)
    st.markdown('<span class="badge badge-sup">🟠 SUPERVISORS ONLY</span>', unsafe_allow_html=True)

    # Q3
    st.markdown("**Q3. Approximately how many hours per week do you spend on direct supervision of trainee clinical sessions?**")
    st.caption("e.g. sitting in, co-facilitating, observing, post-session debrief")
    st.markdown('<div class="purpose-note">📌 Purpose: Quantifies supervisor time burden — core claim of problem statement. Maps to Lean Canvas: Problem block</div>', unsafe_allow_html=True)
    q3 = st.radio("", [
        "Less than 1 hour",
        "1–2 hours",
        "3–5 hours",
        "More than 5 hours",
        "Not applicable"
    ], key="q3", label_visibility="collapsed")

    # Q4
    st.markdown("**Q4. Has supervision capacity ever been a factor in limiting the number of trainees your service could accommodate?**")
    st.markdown('<div class="purpose-note">📌 Purpose: Directly evidences the bottleneck. Tests Hypothesis 1. Maps to Lean Canvas: Problem block</div>', unsafe_allow_html=True)
    q4 = st.radio("", [
        "Yes, definitely",
        "Yes, to some extent",
        "Not sure",
        "No",
        "Not applicable"
    ], key="q4", label_visibility="collapsed")

    # Q5a
    st.markdown("**Q5. How would you describe the quality of post-session reflection currently available to trainees in your service?**")
    st.markdown('<div class="purpose-note">📌 Purpose: Evidences gap in current provision from supervisor perspective. Maps to Lean Canvas: Existing Alternatives</div>', unsafe_allow_html=True)
    q5 = st.radio("", [
        "Very good",
        "Good",
        "Adequate",
        "Poor",
        "Very poor",
        "Not sure"
    ], key="q5_sup", label_visibility="collapsed")

    # Q6a
    st.markdown("**Q6. How often do trainees in your service seek guidance or support between formal supervision sessions?**")
    st.markdown('<div class="purpose-note">📌 Purpose: Validates the inter-session gap SupervisAI addresses. Tests Hypothesis 2</div>', unsafe_allow_html=True)
    q6 = st.radio("", [
        "Very often",
        "Often",
        "Sometimes",
        "Rarely",
        "Never",
        "Not sure"
    ], key="q6_sup", label_visibility="collapsed")

    q7 = None
    q5_tra = None
    q6_tra = None

    st.divider()

# ══════════════════════════════════════════════════════════
# BRANCHING — TRAINEE PATH
# ══════════════════════════════════════════════════════════
if q1 in ["DClinPsy trainee", "Both"]:
    st.markdown('<div class="section-header section-tra">Section 3: Placement Experience — TRAINEES ONLY</div>', unsafe_allow_html=True)
    st.markdown('<span class="badge badge-tra">🟢 TRAINEES ONLY</span>', unsafe_allow_html=True)

    # Q5b
    st.markdown("**Q5. How would you describe the quality of post-session reflection currently available to you in your placement?**")
    st.markdown('<div class="purpose-note">📌 Purpose: Evidences gap in current provision from trainee perspective. Tests Hypothesis 2</div>', unsafe_allow_html=True)
    q5_tra = st.radio("", [
        "Very good",
        "Good",
        "Adequate",
        "Poor",
        "Very poor",
        "Not sure"
    ], key="q5_tra", label_visibility="collapsed")

    # Q6b
    st.markdown("**Q6. How often do you seek clinical guidance or support between your formal supervision sessions?**")
    st.markdown('<div class="purpose-note">📌 Purpose: Validates the inter-session gap from trainee experience. Tests Hypothesis 2</div>', unsafe_allow_html=True)
    q6_tra = st.radio("", [
        "Very often",
        "Often",
        "Sometimes",
        "Rarely",
        "Never"
    ], key="q6_tra", label_visibility="collapsed")

    # Q7
    st.markdown("**Q7. How do you currently reflect on sessions between supervision meetings?** *(select all that apply)*")
    st.markdown('<div class="purpose-note">📌 Purpose: Identifies current workarounds — validates problem is real and unsolved. Maps to Lean Canvas: Existing Alternatives</div>', unsafe_allow_html=True)
    q7_opts = [
        "Written notes or reflective journal",
        "Informal discussion with colleagues",
        "Self-directed reading",
        "No structured process",
        "Other"
    ]
    q7 = [opt for opt in q7_opts if st.checkbox(opt, key=f"q7_{opt}")]

    if q1 == "DClinPsy trainee":
        q3 = q4 = q5 = q6 = None

    st.divider()

# ══════════════════════════════════════════════════════════
# SECTION 4 — ALL REUNITE
# ══════════════════════════════════════════════════════════
st.markdown('<div class="section-header section-all">Section 4: Views on AI & Digital Tools</div>', unsafe_allow_html=True)
st.markdown('<span class="badge badge-all">🔵 ALL RESPONDENTS</span>', unsafe_allow_html=True)

# Q8
st.markdown("**Q8. Are there any existing tools or processes in your service that help address supervision workload or trainee reflection?**")
st.markdown('<div class="purpose-note">📌 Purpose: Lean Canvas — Existing Alternatives block. Validates gap in current market</div>', unsafe_allow_html=True)
q8 = st.radio("", [
    "Yes, and they work well",
    "Yes, but inadequate",
    "No",
    "Not sure"
], key="q8", label_visibility="collapsed")

# Q9
st.markdown("**Q9. How do you currently feel about the use of digital tools in clinical training and supervision?**")
st.markdown('<div class="purpose-note">📌 Purpose: Measures baseline attitudes before introducing AI concept. Tests Hypothesis 3</div>', unsafe_allow_html=True)
q9 = st.radio("", [
    "Very positive",
    "Positive",
    "Neutral",
    "Negative",
    "Very negative"
], key="q9", label_visibility="collapsed")

# Q10
st.markdown("**Q10. How useful would an AI tool be that guided trainees through structured reflection after sessions and tracked their competency progress between supervision meetings?**")
st.caption("1 = not at all useful, 5 = extremely useful")
st.markdown('<div class="purpose-note">📌 Purpose: Core demand validation — tests whether solution concept resonates. Tests Hypothesis 3</div>', unsafe_allow_html=True)
q10 = st.select_slider("", options=[
    "1 — Not at all useful", "2", "3 — Neutral", "4", "5 — Extremely useful"
], key="q10", label_visibility="collapsed")

# Q11
st.markdown("**Q11. How easily could a digital reflection tool fit into your current working routine?**")
st.markdown('<div class="purpose-note">📌 Purpose: Workflow fit — most common failure point for NHS healthtech. Maps to Lean Canvas: Channels</div>', unsafe_allow_html=True)
q11 = st.radio("", [
    "Very easily",
    "Fairly easily",
    "Neutral",
    "With some difficulty",
    "Very difficult"
], key="q11", label_visibility="collapsed")

# Q12
st.markdown("**Q12. If a tool like this existed, would you use or recommend it?**")
st.markdown('<div class="purpose-note">📌 Purpose: Adoption intent — standard closing validation in healthtech. Tests Hypothesis 3</div>', unsafe_allow_html=True)
q12 = st.radio("", [
    "Definitely yes",
    "Probably yes",
    "Not sure",
    "Probably not",
    "Definitely not"
], key="q12", label_visibility="collapsed")

st.divider()

# ══════════════════════════════════════════════════════════
# SECTION 5 — IMPACT & DISCOVERY
# ══════════════════════════════════════════════════════════
st.markdown('<div class="section-header section-all">Section 5: Impact & Discovery</div>', unsafe_allow_html=True)
st.markdown('<span class="badge badge-all">🔵 ALL RESPONDENTS</span>', unsafe_allow_html=True)

# Q13
st.markdown("**Q13. What would make you consider a digital supervision support tool successful in your service?** *(select all that apply)*")
st.markdown('<div class="purpose-note">📌 Purpose: Lean Canvas — Key Metrics block. Captures user-defined success including downstream patient impact</div>', unsafe_allow_html=True)
q13_opts = [
    "Reduction in hours supervisors spend on direct session support",
    "More time for supervisors to focus on other clinical responsibilities",
    "Improved supervisor wellbeing and reduced burnout",
    "Increased trainee confidence and independence between sessions",
    "More structured and consistent reflection process for trainees",
    "Ability to accommodate more trainees in the service",
    "Better competency tracking and progression visibility",
    "Reduced waiting times for clients accessing the service",
    "Other"
]
q13 = [opt for opt in q13_opts if st.checkbox(opt, key=f"q13_{opt}")]

st.markdown("")

# Q14
st.markdown("**Q14. How would you most likely hear about and adopt a new digital tool for clinical supervision?** *(select all that apply)*")
st.markdown('<div class="purpose-note">📌 Purpose: Lean Canvas — Channels block. Informs B2B2C distribution strategy and go-to-market approach</div>', unsafe_allow_html=True)
q14_opts = [
    "Recommendation from a colleague",
    "NHS England or trust-level rollout",
    "BPS or HCPC endorsement",
    "DClinPsy programme director recommendation",
    "Social media or professional networks",
    "Other"
]
q14 = [opt for opt in q14_opts if st.checkbox(opt, key=f"q14_{opt}")]

st.divider()

# ══════════════════════════════════════════════════════════
# SECTION 6 — OPEN FEEDBACK
# ══════════════════════════════════════════════════════════
st.markdown('<div class="section-header section-all">Section 6: Open Feedback</div>', unsafe_allow_html=True)
st.markdown('<span class="badge badge-all">🔵 ALL RESPONDENTS</span>', unsafe_allow_html=True)

# Q15a
st.markdown("**Q15a. What would be your biggest concern about using an AI tool to support clinical supervision?** *(select all that apply)*")
st.markdown('<div class="purpose-note">📌 Purpose: Quantifiable concern data — each concern maps to a mitigation in the product. Maps to Lean Canvas: Unfair Advantage</div>', unsafe_allow_html=True)
q15a_opts = [
    "Data privacy and confidentiality",
    "Accuracy and reliability of the tool",
    "Risk of replacing human clinical judgement",
    "Impact on the trainee-supervisor relationship",
    "Increased workload for supervisors or trainees",
    "Lack of NHS data security compliance",
    "No concerns",
    "Other"
]
q15a = [opt for opt in q15a_opts if st.checkbox(opt, key=f"q15a_{opt}")]

st.markdown("")

# Q15b
st.markdown("**Q15b. Is there anything else you'd like to share about your experience of clinical supervision or training?**")
st.markdown('<div class="purpose-note">📌 Purpose: Open text — captures unexpected insight and qualitative depth</div>', unsafe_allow_html=True)
q15b = st.text_area("", placeholder="Your response here...", height=120, key="q15b", label_visibility="collapsed")

st.divider()

# ══════════════════════════════════════════════════════════
# SUBMIT
# ══════════════════════════════════════════════════════════
if st.button("Submit Survey"):
    response = {
        "role": q1,
        "digital_tool_experience": q2,
        "sup_hours": q3 if q1 in ["DClinPsy supervisor", "Both"] else "N/A",
        "sup_capacity_limited": q4 if q1 in ["DClinPsy supervisor", "Both"] else "N/A",
        "sup_reflection_quality": q5 if q1 in ["DClinPsy supervisor", "Both"] else "N/A",
        "sup_intersession_freq": q6 if q1 in ["DClinPsy supervisor", "Both"] else "N/A",
        "tra_reflection_quality": q5_tra if q1 in ["DClinPsy trainee", "Both"] else "N/A",
        "tra_intersession_freq": q6_tra if q1 in ["DClinPsy trainee", "Both"] else "N/A",
        "tra_reflection_methods": "|".join(q7) if q7 and q1 in ["DClinPsy trainee", "Both"] else "N/A",
        "existing_tools": q8,
        "digital_attitude": q9,
        "usefulness_rating": q10,
        "workflow_fit": q11,
        "adoption_intent": q12,
        "success_metrics": "|".join(q13) if q13 else "None selected",
        "discovery_channels": "|".join(q14) if q14 else "None selected",
        "concerns": "|".join(q15a) if q15a else "None selected",
        "open_feedback": q15b
    }
    save_response(response)
    st.session_state.submitted = True
    st.rerun()

# ── FOOTER ──────────────────────────────────────────────────
st.markdown("""
<div class="footer-note">
This survey is anonymous. Data will be used solely for an independent research project 
and will not be shared with third parties. Your participation is voluntary and you may 
withdraw at any time.
</div>
""", unsafe_allow_html=True)
